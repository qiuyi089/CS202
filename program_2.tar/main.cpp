/*
the client file that will be telling the user what to do
*/
#include"book.h"


int main(){
	general_material hw;//create an object of the general_material class
	char res;
	char temp[20];
	do{
		//ask the user what they would like to do
		cout<<"What would you like to do? \n";
		cout<<"(A)New reading material (B)New exercise \n";
		cin>>res;
		cin.ignore(100,'\n');
		//if they choose a then ask them the course name 
		//pass the information to the insert funcation.
		if(tolower(res) == 'a'){
			cout<<"For what class: ";
			cin.get(temp,20,'\n');
			cin.ignore(100,'\n');

			hw.insert(temp,res);
			hw.display();
		}
		//if they choose b do the same thing
		if(tolower(res) == 'b'){
			cout<<"For what class: ";
			cin.get(temp,20,'\n');
			cin.ignore(100,'\n');
			
			hw.insert(temp,res);
			hw.display();	
		}
		//ask them if they want to continue
		//if they choose to press q then exit out
		cout<<"Continue: ";
		cout<<"To end the program press q.\n"
		cin>>res;
		cin.ignore(100,'\n');
	}while(tolower(res) != 'q');

};






