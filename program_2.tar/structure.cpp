/*
This file is for impliment the function ijn the structure.h file
*/
#include"structure.h"

//the initialize data member of the reading class
reading::reading():title(NULL),author(NULL),chapter(0),page(0){

}
//copy contructor for the reading class
reading::reading(char * title_add, char * author_add,int chapter_add,int page_add){
	if(title_add){
		title = new char[strlen(title_add) +1];
		strcpy(title,title_add);
	}
	if(author_add){
		author = new char[strlen(author_add) + 1];
		strcpy(author,author_add);
	}
	chapter = chapter_add;
	page = page_add;


}
//copy contructor for the reading class
reading::reading(const reading & to_add){
	if(to_add.title){
		title = new char[strlen(to_add.title) +1];
		strcpy(title,to_add.title);
	}
	if(to_add.author){
		author = new char[strlen(to_add.author) + 1];
		strcpy(author,to_add.author);
	}
	chapter = to_add.chapter;
	page = to_add.page;
}
//decontructor for the reading class
reading::~reading(){
	if(title){
		delete [] title;
		title = NULL;
	}
	if(author){
		delete [] author;
		author = NULL;
	}
	chapter = 0;
	page = 0;
}
//contructor for the exercise class
exercise::exercise():q_name(NULL),question(NULL){
}
//copy constructor for the exercise class
exercise::exercise(char * q_name_add, char * question_add){
	if(q_name_add){
		q_name = new char[strlen(q_name_add) + 1];
		strcpy(q_name,q_name_add);
	}
	if(question_add){
		question = new char[strlen(question_add) + 1];
		strcpy(question,question_add);
	}
}
//copy constructor for the exercise class
exercise::exercise(const exercise & to_add){
	if(to_add.q_name){
		q_name = new char[strlen(to_add.q_name) + 1];
		strcpy(q_name,to_add.q_name);
	}
	if(to_add.question){
		question = new char[strlen(to_add.question) + 1];
		strcpy(question,to_add.question);
	}
}
//decontructor for the exercise class
exercise::~exercise(){
	if(q_name){
		delete [] q_name;
		q_name = NULL;
	}
	if(question){
		delete [] question;
		question = NULL;
	}
}
//constructor for the LLL class
LLL::LLL():data(NULL),next(NULL){
}
//deconstructor for the LLL class
LLL::~LLL(){
	if(data){
		delete data;
		data = NULL;
	}
	if(next){
		delete next;
		next = NULL;
	}
}
//contructor for the CLL class
CLL::CLL():next(NULL),data(NULL){
}
//deconstructor for the CLL class
CLL::~CLL(){
	if(data){
		delete data;
		data = NULL;
	}
}
//display the data in the reading class
int reading::display(){
	if(!title)
		return 0;
	cout<<"The book title is: "<<title<<"\n";
	cout<<"The author is: "<<author<<"\n";
	cout<<"Chapter: "<<chapter<<"\n";
	cout<<"Page: "<<page<<"\n";
	return 1;
}
//display the data in te evercise class
int exercise::display(){
	cout<<"The exercise is: "<<q_name<<"\n";
	cout<<"The question is: "<<question<<"\n";
	return 1;
}
//Go to the next node by
//return the next node pointer from a LLL back
LLL * LLL::go_next(){
	return next;
}
//insert the data in LLL
int LLL::insert(reading & to_add){
	if(!data){
		data = new reading(to_add); 
		next = NULL;
		return 1;
	}
	return 0;	
}
//insert the data in LLL
int LLL::insert(char * title_add,char * author_add,int chapter_add,int page_add){
	if(!data){
		data = new reading(title_add,author_add,chapter_add,page_add);
		next = NULL;
		return 1;
	}
	return 0;

}
//Set next to temp which is to connect up the list;
int LLL::set_next(LLL * temp){
	next = temp;
	return 1;
}
//wrapper function that will call the display function
int LLL::display(){
	data -> display();
	return display(next);
}
//recursive call to move to the next node
int LLL::display(LLL * head){
	if(!head)
		return 0;
	
	head -> data -> display();
	return display(head -> next);
}
//Insert the data in the CLL 
int CLL::insert(char * q_name_add,char * question_add){
	if(!data){
		data = new exercise(q_name_add,question_add);
		next = NULL;
		return 1;
	}
	return 0;
}
//set the next node in the CLL
int CLL::set_next(CLL * temp){
	next = temp;
	return 1;
}
//go to the next node in the CLLL
CLL *& CLL::go_next(){
	return next;
}
//dipslay the data int the CLL
int CLL::display(){
	data -> display();
	return 1;
}







