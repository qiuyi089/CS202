/*
Dung Nguyen
CS202
program_2

This structure file is responsible for all the information that will be taking in the 
information from the client and create copy of them, and store them in
different data structure.


*/
#include<iostream>
#include<cstring>
#include<cctype>

using namespace std;

//this class will be responsible for the reading information
class reading{
	public:
		reading();//constructor
		reading(char * title_add, char * author_add,int chapter_add,int page_add);//copy constructor 
		reading(const reading  & to_add);//copy contructor
		~reading();//deconstructor
		int display();//display the information 
	private:
		char * title;
		char * author;
		int chapter;
		int page;

};
//this class will be resoponsible for the exercise question
class exercise{
	public:
		exercise();//constructor
		exercise(char * q_name_add,char * question_add);//coppy constructor
		exercise(const exercise & to_add);//copy contructor
		~exercise();//deconstructor
		int display();//display the information
	private:
		char * q_name;
		char * question;
};
//this class will be responsible for Linear LInk list task
class LLL{
	public:
		LLL();//constructor
		~LLL();//decontructor
		int insert(reading & to_add);//copy the informatio
		int insert(char * title_add,char * author_add,int chapter,int page_add);//copy the information
		LLL * go_next();//go to the next node
		int set_next(LLL * temp);//set next to another node
		int display();//display the information in the list	
	private:
		int display(LLL * head);//recursive function that will move on the the next node
		reading * data;
		LLL * next;	
};
//this class will be responsible for the Circular link list
class CLL{
	public:
		CLL();//constructor
		~CLL();//deconstructor
		int insert(char * q_name_add,char * question_add);//insert the information taken from main	
		CLL *& go_next();//go to the next node
		int set_next(CLL * temp);//set the next node to another node
		int display();//display the information
	private:
		int display(CLL * head);//recursive funcation that will move on to the next node to display
		CLL * next;	
		exercise * data;
};







