/*
this file is for implimenting the function in the book.h file

*/
#include"book.h"
//constructor
general_material::general_material():data(NULL),next(NULL),previous(NULL),course(NULL){
}
//copy constructor
general_material::general_material(char * add){
	course = new char[strlen(add) + 1];
	strcpy(course,add);
	
	data = NULL;
	next = NULL;
	previous = NULL;
}
//decontructor
general_material::~general_material(){
	if(course){
		delete course;
		course = NULL;
	}
	if(next){
		delete next;
		next = NULL;
	}
	if(previous){
		delete previous;
		previous = NULL;
	}
}
//contructor for the readin material class
reading_material::reading_material():head(NULL),tail(NULL){
}
//deconstructor for the reading class
reading_material::~reading_material(){
	if(head){
		remove(head);
		head = NULL;	
	}
}
//constructor for the exercise material class
exercise_material::exercise_material():rear(NULL){
}
//deconstructor for the exercise material calss
exercise_material::~exercise_material(){
	if(rear){
		CLL * temp = rear -> go_next();
		rear -> set_next(NULL);
		remove(temp);
		rear = NULL;
	}
}
/*
the contructor and deconstructor for the video class

video_material::video_material(){
}
video_material::~video_material(){
}
*/
//insert the material base on class nd their 
int general_material::insert(char * add,char choice){	
	//if there is nothing in the material yet then create a deep copy of the course
	//then check if the data exist or not if not then create a new data and 
	//set it to either reading material or exercise material base on 
	// the client choice	
	if(!course){
		course = new char[strlen(add) + 1];
		strcpy(course,add);
	}
	if(!data){	
		if(tolower(choice) == 'a'){
			data = new reading_material;
			data -> new_material();
			return 1;
		}
		if(tolower(choice) == 'b'){
			data = new exercise_material;
			data -> new_material();
			return 1;
		}
	}
	if(strcmp(course,add) == 0){
		data -> new_material();
		return 1;
	}
	return insert(add,choice,next,data);
}
//recursive call for the general class which will move on to the next node for a new course
int general_material::insert(char * add,char choice,general_material *& head,general_material * temp){
	//if there is nothing in head then create a new node
	//set the data to either reading or exercise base on the choice
	//connect up the node to the previous one. If there is data then move on to
	// the next node
	if(!head){
		head = new general_material(add);
		if(tolower(choice) == 'a'){
			head -> data = new reading_material;
			head -> data -> new_material();
		}
		if(tolower(choice) == 'b'){
			head -> data = new exercise_material;
			head -> data -> new_material();
		}
		head -> previous = temp;
		head -> next = NULL;
		return 1;
	}
	return insert(add,choice,head -> next,head);
}
//go to the next node
general_material *& general_material::go_next(){
	return next;
}
//display the information in the DLL
int general_material::display(){
	if(!data)
		return 0;
	cout<<" \n";
	cout<<"Class: "<<course<<"\n";
	data -> display();
	cout<<" \n";
	return display(next);
}
//recursive call to display the information in the DLL
//check if head is empty if it not then display and move on
//else exit out the loop
int general_material::display(general_material * head){
	if(!head)
		return 0;
	cout<<"Class: "<<head -> course<<"\n";
	head -> data -> display();
	cout<<"\n";
	return display(head -> next);
}
//virtual function for new material
int general_material::new_material(){
}
//remove every node in the CLL 
int exercise_material::remove(CLL *& rear){
	if(!rear)
		return 0;
	CLL * temp = rear;
	rear = temp -> go_next();
	delete temp;
	return remove(rear);
}
//remove everything in the LLL 
int reading_material::remove(LLL *& head){
	if(!head)
		return 0;
	LLL * temp = head;
	head = temp -> go_next();
	delete temp;
	return remove(head);
}
//ask the user the information about the new material
int reading_material::new_material(){
	char title_temp[30];
	char author_temp[30];
	char q_name_temp[20];
	char question_temp[50];
	int chapter_temp;
	int page_temp;	
	cout<<"title \n";
	cin.get(title_temp,20,'\n');
	cin.ignore(100,'\n');

	cout<<"author \n";
	cin.get(author_temp,20,'\n');
	cin.ignore(100,'\n');

	cout<<"chapter: ";
	cin>>chapter_temp;
	cin.ignore(100,'\n');

	cout<<"page: ";
	cin>>page_temp;
	cin.ignore(100,'\n');
	
	return new_material(title_temp,author_temp,chapter_temp,page_temp);//pass the information to the other function to add 
}
//create a node and add the information into the list
int reading_material::new_material(char * title_add,char * author_add,int chapter_add,int page_add){
	if(!head){
		head = new LLL;
		head -> insert(title_add,author_add,chapter_add,page_add);
		tail = head;
		return 1;
	}
	LLL * temp = new LLL;
	temp -> insert(title_add,author_add,chapter_add,page_add);
	tail -> set_next(temp);
	return 1;
}
//display the information in the reading material
int reading_material::display(){
	if(!head)
		return 0;
	return head -> display();
}
//ask the client for the exercise material
int exercise_material::new_material(){
	char q_name_temp[40];
	char question_temp[50];

	cout<<"What is the exercise name: \n";
	cin.get(q_name_temp,40,'\n');
	cin.ignore(100,'\n');

	cout<<"What is the question: \n";
	cin.get(question_temp,50,'\n');
	cin.ignore(100,'\n');

	return new_material(q_name_temp,question_temp);//pass the information into another fucntion to add the information
}
//create a new node in the list and add the information into the node for the CLL
int exercise_material::new_material(char * q_name_add, char * question_add){
	if(!rear){
		rear = new CLL;
		rear -> insert(q_name_add,question_add);
		rear -> set_next(rear);
		return 1;
	}
	CLL * temp = new CLL;
	temp -> insert(q_name_add,question_add);
	temp -> set_next(rear -> go_next());
	rear -> set_next(temp);
	rear = temp;
	return 1;
}
//display the CLL
int exercise_material::display(){	
	CLL * temp = rear -> go_next();
	return display(temp);
}
//recursive call to display the CLL
int exercise_material::display(CLL * rear){
	if(!rear)
		return 0;
	if(rear == this -> rear){
		rear -> display();
		return 1;
	}
	rear -> display();
	CLL * temp = rear -> go_next();
	return display(temp);
}


