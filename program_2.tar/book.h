/*
Dung Nguyen
CS202
program 2

this file will be responsible for the material that the user want to enter in
*/
#include"structure.h"
//This class is the base class that other class will be derive from
class general_material{
	public:
		general_material();//constructor
		general_material(char * add);//copy constructor
		~general_material();//decontructor
		
		general_material *& go_next();//go to the next node		
		virtual int new_material();//a virtual function for adding new material for a specific course	
	    int insert(char * add,char choice);//create a new material
		virtual int display();//a virtual function to dipslay the information
	protected:
		int insert(char * add,char choice,general_material *& head,general_material * temp);//insert the information into the course
		int display(general_material * head);//recursive function to tmove to the next node
		char * course;//course name		
		general_material * data;//can be either reading or exercise material
		general_material * next;//next node
		general_material * previous;//previous node	
};
//this class is derive from the general_materla class
//it will be responsible for all the reading material
class reading_material:public general_material{
	public:
		reading_material();//constructor
		~reading_material();//deconstructor

		int new_material();//make the new material and ask the user the information
		int display();//display the information
		int remove(LLL *& head);//remove the LLL
	protected:
		int new_material(char * title_add,char * author_add,int chapter_add,int page_add);//copy the information into the list
		LLL * head;//head of the LLL
		LLL * tail;//tail of the LLL
};
//this clas will be responsible for exercise material
//it derive from the general material class
class exercise_material:public general_material{
	public:
		exercise_material();//contructor
		~exercise_material();//deconstructor

		int new_material();//create a new material and ask the information from the user
		int display();//display the information
		int remove(CLL *& head);//remove the CLL
	protected:
		int new_material(char * q_name_add,char * question_add);//copy the information into the list
		CLL * rear;//rear of the CLL
		int display(CLL * rear);//recursive call to display the list


};
/*
This class will be responsible for the video material but not 
yet to be implement

class video_material:public general_material{
	public:
		video_material();
		~video_material();
		int display();
		int insert();
	protected:


};
*/




