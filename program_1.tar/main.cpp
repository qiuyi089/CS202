/*
	Dung Nguyen
	CS202
	4/27/18

	This is the main file which will act as the 
	client. It will read in the information and pass it to the 
	class to handle.


*/

#include "delivery.h"

int main(){
	graph maps;//make a object for graph
	standard amazon;//make a object for standard
	express ups;//make a object for express
	char res;//store the client respond
		
	
	do{	
		//ask them what they want to do
		cout<<"What would you like to do? \n";
		cout<<"(A)Enter in the order \n";
		cin>>res;//take in the respond
		cin.ignore(100,'\n');	
		if(tolower(res) == 'a'){
			order temp;//create a temp object to store information
			temp.location = new char[20];//allocate memory
			temp.item = new char[20];//allocate memory
			char temp2[20];		
			char temp3[9] = "standard";
			char temp4[8] = "express";	
			maps.display_location();//show them the available location to delivery
			cout<<"Here is the availible location to delivery. \n";
			//ask them for the item name 
			//it weight and dimension
			cout<<"Please enter in the location you want the package to go: ";
			cin.get(temp.location,20,'\n');
			cin.ignore(100,'\n');

			cout<<"What is the item you want to order: ";
			cin.get(temp.item,20,'\n');
			cin.ignore(100,'\n');

			cout<<"How heavy is the package: ";
			cin>>temp.weight;
			cin.ignore(100,'\n');

			cout<<"What is the dimension of the package: ";
			cin>>temp.dimension;
			cin.ignore(100,'\n');

			cout<<"What is the method of delivery: ";
			cin.get(temp2,100,'\n');
			cin.ignore(100,'\n');
			//check if what type of delivery they wanted
			if(strcmp(temp2,temp3) == 0)	
				amazon.take_order(temp);
			if(strcmp(temp2,temp4) == 0)
				ups.take_order1(temp);
		}
	}while(tolower(res) != 'q');//keep on looping until the client press quit
	
	

};
