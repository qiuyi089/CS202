/*

	Dung Nguyen
	CS202
	4/27/2018

	The purpose of program 1 is to create a delivery system that will take in the order and create a 
	Linear Link List out of it. This header file is specificly for creating a graph which 
	will ultimately serve as a maps for that is need for the delivery service use to find the shortest path
	to the destination. The graph class is to initalize all the location by calling the vertex class to store
	the location in. Then it will make the edge by using the node class that will connect up all
	the location to each other.






*/


//include the neccessary library
#include<iostream>
#include<cstring>
#include<cctype>
#include<cstdlib>

using namespace std;

//create the prototype for the class
class node;
class graph;

//This is the vertex class which will be managing the location information
//in the graph
class vertex{
	public:
		vertex();//initialize it data member
		~vertex();//deallocate the data member
		vertex(char * to_add);//copy constructor
		int create_location(char * source);//add the location into the array		
		int display();//display location
		char * location;
		node * head;
};

//this class is manage the graph which will make the road
class graph{
	
	public:
		
		graph();//initialize all the data member
		~graph();//deallocate the data member

		int distance_travel();
		int find();
		int make_road();//make the road for the graph
		int display_location();//display the availible location to the user
	protected:	
		vertex * adjacency_list;//the array of the location
		int size;//maxium number of location
	private:
		int make_road(int current_vertex,int to_attach,char * road1);//create edge to the location
	
};
//This class will be responsible for the edge 
class node{
	public:
		node();//initialize the data member
		~node();//deallocate the data member
		node(char * to_add);//copy constructor
		int road_choice(char * road);
		vertex * adjacent;//store the location information
		node * next;//store what can be reach by the location
		int speed_limit;//speed limit that the road set
		int time;//time it take to travel
		char * road_type;//the road type like freeway, shortcut
};

//this class will create a CLL that will store the path to take
//for the shortest route
class CLL:public graph{
	public:
		CLL();
		~CLL();
		
		int find_fastest(char * dest);
		int find_dest(char * dest);
		int update(CLL *& head);
		int check(int total,node * head);
		int make_fast_route();
		int give_estimation();
		int path;
	private:
		CLL * next;
		CLL * head;
		CLL * tail;
};



