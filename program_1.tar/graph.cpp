/*

	Dung Nguyen
	CS202
	4/27/18

	This file is the implimentation of the 
	graph header file.


*/



#include "delivery.h"

//constructor for the graph class
graph::graph(){
	size = 20;//set the size of the array to be 20
	adjacency_list = new vertex[size];//allocate the memory for 20 location
	
	//Enter in 20 different location for the graph
	char location1[20] = "Henderson";
	adjacency_list[0].create_location(location1);
		
	char location2[20] = "Bybee";
	adjacency_list[1].create_location(location2);
		
	char location3[20] = "Main";
	adjacency_list[2].create_location(location3);
		
	char location4[20] = "Park";
	adjacency_list[3].create_location(location4);
	
	char location5[20] = "Nora";
	adjacency_list[4].create_location(location5);
	
	char location6[20] = "Bristal";
	adjacency_list[5].create_location(location6);
	
	char location7[20] = "Maple";
	adjacency_list[6].create_location(location7);
	
	char location8[20] = "Cedar";
	adjacency_list[7].create_location(location8);
	
	char location9[20] = "Lindon";
	adjacency_list[8].create_location(location9);
	
	char location10[20] = "Broadway";
	adjacency_list[9].create_location(location10);
	
	char location11[20] = "Ravine";
	adjacency_list[10].create_location(location11);
	
	char location12[20] = "flagstone";
	adjacency_list[11].create_location(location12);
	
	char location13[20] = "Sunny";
	adjacency_list[12].create_location(location13);
	
	char location14[20] = "Burnside";
	adjacency_list[13].create_location(location14);
	
	char location15[20] = "Rigert";
	adjacency_list[14].create_location(location15);
	
	char location16[20] = "Lori";
	adjacency_list[15].create_location(location16);
	
	char location17[20] = "Glassway";
	adjacency_list[16].create_location(location17);
	
	char location18[20] = "Stark";
	adjacency_list[17].create_location(location18);
	
	char location19[20] = "Division";
	adjacency_list[18].create_location(location19);
	
	char location20[25] = "Amazon store";
	adjacency_list[19].create_location(location20);
																		
	make_road();//call the create road to make connection 

}

//deconstructor for the graph
graph::~graph(){
	//delete the LLL in each index
	if(adjacency_list){
		//delete the adjacency list array and set it to null
		delete [] adjacency_list;
		adjacency_list = NULL;
	}
}
//constructor for the vertex function
vertex::vertex(){
	//set the head and location to null
	head = NULL;
	location = NULL;
}
//copy contructor
vertex::vertex(char * to_add){
	//if to add exist then allocate new space for location 
	//else set location to null
	if(to_add){
		location = new char[strlen(to_add) + 1];
		strcpy(location,to_add);
	}
	else{
		location = NULL;
	}
}
//deconstructor for the vertex
vertex::~vertex(){
	//if location exist then delete it then set it to null
	if(location){
		delete [] location;
		location = NULL;
	}
	if(head){
		delete head;
		head = NULL;
	}
}
//constructor for the CLL
CLL::CLL(){
	//set next, tail, and head to null
	// path to 0
	path = 0;
	next = NULL;
	tail = NULL;
	head = NULL;
}
//deconstructor for the CLL
CLL::~CLL(){
	//if next, tail, and head exist then delete those and set them to null
	if(next){
		delete next;
		next = NULL;
	}
	if(tail){
		delete tail;
		tail = NULL;
	}

}
//constructor for the node class
node::node(){
	//set adjacent, next, and road type  to null
	//speed limit and time to random
	adjacent = NULL;
	next = NULL;
	speed_limit = rand() % 45 + 1;
	time = rand() % 5 + 1;
	road_type = NULL;
}
//copy_constructor
node::node(char * to_add){
	if(to_add){
		road_type = new char[strlen(to_add) +1];
		strcpy(road_type,to_add);
	}
}
//decontructor
node::~node(){
	//if next and road type exist then delete and set to null
	if(next){
		delete next;
		next = NULL;
	}
	if(road_type){
		delete [] road_type;
		road_type = NULL;
	}
	
	speed_limit = 0;
	time = 0;

}
//this function will create a deep copy of the location in to the array
int vertex::create_location(char * source){
	location = new char[strlen(source) + 1];
	strcpy(location,source);
	return 1;
}
//display the availible location to the client
int vertex::display(){
	cout<<location<<"\n";
}

int node::road_choice(char * road){
	road_type = new char[strlen(road) + 1];
	strcpy(road_type,road);
	return 1;
}

//this function will call the recusive function that will make 
//the connection between the vertex
int graph::make_road(){
	//3 types of roads
	char temp1[10] = "freeway";
	char temp2[16] = "main roads";
	char temp3[17] = "short cut";

	//creating the connection between the vertex
	make_road(19,17,temp2);
	make_road(19,16,temp2);
	make_road(19,18,temp1);
	make_road(16,14,temp1);
	make_road(18,13,temp2);
	make_road(17,15,temp2);
	make_road(14,11,temp2);
	make_road(15,11,temp2);
	make_road(15,12,temp3);
	make_road(13,10,temp2);
	make_road(13,0,temp3);
	make_road(10,8,temp1);
	make_road(11,8,temp2);
	make_road(11,9,temp1);
	make_road(8,5,temp2);
	make_road(8,6,temp2);
	make_road(5,7,temp2);
	make_road(5,2,temp2);
	make_road(6,3,temp2);
	make_road(6,12,temp1);
	make_road(3,4,temp1);
	make_road(2,1,temp3);
	make_road(1,0,temp2);	
	return 1;
}
//make the connection between 2 vertex
int graph::make_road(int current_vertex,int to_attach,char * road1){
	//if there is no connection then make a new one
	if(!adjacency_list[current_vertex].head){
		adjacency_list[current_vertex].head = new node;
		adjacency_list[current_vertex].head -> road_choice(road1);
		adjacency_list[current_vertex].head -> adjacent = &adjacency_list[to_attach];
		adjacency_list[current_vertex].head -> next = NULL;
		return 1;
	}
	node * temp = adjacency_list[current_vertex].head;
	adjacency_list[current_vertex].head = new node;
	adjacency_list[current_vertex].head -> adjacent = &adjacency_list[to_attach]; 
	adjacency_list[current_vertex].head -> road_choice(road1);
	adjacency_list[current_vertex].head -> next = temp;
	return 1;
}
//travel the array to display the location
int graph::display_location(){
	cout<<"The location are available are: \n";

	for(int i = 0; i < 20; ++i)
		adjacency_list[i].display();

}
