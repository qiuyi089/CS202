/*

	Dung Nguyen
	CS202
	4/27/18

	This file is the implimentation of the 
	delivery header file.



*/

#include "delivery.h"
//constructor for order
order::order(){
	//initialize the location and item to null
	//weight and dimension to 0
	location = NULL;
	weight = 0;
	dimension = 0;	
	item = NULL;
}
//copy constructor for order
order::order(const order & to_add){
	//if there item and location exist then allocate new space for the 
	//data and deep copy.
	if(to_add.item){
		item = new char[strlen(to_add.item) + 1];
		strcpy(item,to_add.item);
	}
	if(to_add.location){
		location = new char[strlen(to_add.location) + 1];
		strcpy(location,to_add.location);
	}
	weight = to_add.weight;
	dimension = to_add.dimension;
}
//deconstructor for order
order::~order(){
	//if location exist then delete and same for item
	if(location){
		delete [] location;
		location = NULL;
	}
	if(item){
		delete [] item;
		item = NULL;
	}
	weight = 0;
	dimension = 0;	
}

delivery::delivery(){

}
delivery::~delivery(){

}
//constructor for standard
standard::standard(){
	//set the pointer to null
	package1 = NULL;
	tail_1 = NULL;
	max_package = 0;
}
//decontructor for standard
standard::~standard(){
	//if there are package then delete it and set it to null
	if(package1){
		delete package1;
		package1 = NULL;
	}
	max_package = 0;
}
//constructor for express
express::express(){
	//set the pointer to null
	package2 = NULL;
	tail_2 = NULL;
	MAX = 0;

}
//deconstructor for express
express::~express(){
	//if there is package then delete it set it to null
	if(package2){
		delete package2;
		package2 = NULL;
	}
	MAX = 0;	
}
//constructor for LLL
LLL::LLL(){
	next = NULL;
	data = NULL;	
}
//decontructor for LLL
LLL::~LLL(){
	//if next and data exist then delete and set them both to null
	if(next){
		delete next;
		next = NULL;
	}
	
	if(data){
		delete data;
		data = NULL;
	}
}
//take in the order from the client for the standard 
int standard::take_order(const order to_add){
	//if reach maximum package that the cart can handle then exist
	if(max_package == 10){
		cout<<"The standard car is full! \n";
		return 1;
	}
	//if there is nothing in the cart yet
	//add at the front of the list
	if(!package1){
		package1 = new LLL;
		package1 -> data = new order(to_add);
		package1 -> next = NULL;
		tail_1 = package1;
		max_package+=1;
		return 1;
	}
	//else add at the end of the list
	tail_1 -> next = new LLL;
	tail_1 -> next -> data = new order(to_add);
	tail_1 -> next -> next = NULL;
	tail_1 = tail_1 -> next;
	max_package+=1;
	return 1;
		
}
//take the order for express 
int express::take_order1(const order to_add){
	//check to see if the cart is full
	if(MAX == 3){
		cout<<"The express car is full! \n";
		return 1;
	}
	//if the cart is empty then add at the front of the list
	if(!package2){
		package2 = new LLL;
		package2 -> data = new order(to_add);
		package2 -> next = NULL;
		tail_2 = package2;
		MAX+=1;
		return 1;
	}
	//else add at the end of the list
	tail_2 -> next = new LLL;
	tail_2 -> next -> data = new order(to_add);
	tail_2 -> next -> next = NULL;
	tail_2 = tail_2 -> next;
	MAX+=1;
	return 1;
}








