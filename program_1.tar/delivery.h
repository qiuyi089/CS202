/*

	Dung Nguyen
	CS202
	4/27/2018

	This header file is responsible for take in the order from the client
	and then create an LLL base on what service the client want.
	There will be 3 type of delivery, and they all will have their own way
	of delivery.



*/
#include "graph.h"

//This class will store the information about the order
//and the location that it is need to go
class order{

	public:
		order();//initialize all the data member
		order(const order &  to_add);//copy constructor
		~order();//deallocate the data member
		
		//store the information about the package
		char * item;
		char * location;
		int weight;
		int dimension;

	
};
//create a list of order 
class LLL{

	public:
		LLL();//initilize the data member
		~LLL();//deallocate the data member
		order * data;//containing the order
		LLL * next;//point to the next order
};
//this class will be responsible for delivery the order 
//that the client place
class delivery{

	public:	
		delivery();//initialize the data member
		~delivery();//dealocate the data member
		int delivery_route();	
	protected:
		CLL maps;//use the map to find the fastest route
		
};

//This class will be reponsible for standard delivery
class standard: public delivery{

	public:
		standard();//initialize the data member
		~standard();//deallocate the data member
		int	take_order(const order to_add);//take the order from the client
		int timer();//find out the time it take to finish delivery
		int standard_payment();//calculate the payment base on the number of package
	private:	
		LLL * package1;//head for the LLL of order
		LLL * tail_1;//the tail which will point to the end of LLL	
		int max_package;//maximum number of package can be delivery
};

//This class will be responsible for express delivery
//which will be like standard but can only carry
//3 order
class express: public delivery{

	public:
		express();//initialize the data member
		~express();//deallocate the data member
		int take_order1(const order to_add);//take the order from the client
		int time();//find the time it take to finish the delivery
		int express_payment();//calculate the payment base on time
	
	private:		
		LLL * package2;//head for the LLL of order
		LLL * tail_2;//tail of the LLL		
		int MAX;//maximum number of package that can be carry


};

//This class will be responsible for the drone delivery
class drone: public delivery{
	public:
		drone();//initialize the data member
		~drone();//deallocate the data member

		int drone_delivery();//take in the order
		int check_required();//check if the package acceptable base on weight and dimension
	private:
		int weight;//weight of the package
		int dimension;//dimension of the package


};







